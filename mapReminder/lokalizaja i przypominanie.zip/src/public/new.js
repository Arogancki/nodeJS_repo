function fun(){
    alert('czesc')
    // regeuqf
    // .then(

    document.getElementById('toaj').innerHTML="akfhvabhkfbaifhb kdhffbadahfd"
}